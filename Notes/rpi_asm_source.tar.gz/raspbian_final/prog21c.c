#include <stdio.h>
int main()
{
  printf("hello world");
  return 0;
}

