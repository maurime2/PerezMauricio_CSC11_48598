#include <stdio.h>

int main()
{
   putchar('*');
   return 0;
}

